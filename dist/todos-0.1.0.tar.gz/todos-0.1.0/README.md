## modulo_II

En este repositorio se encuentra la resolucion alas siguientes tareas:

### Parte 1
Modifique lo necesario con el fin de ver reflejado las buenas prácticas que hemos aprendido hasta el momento, a saber

Organizar el código o los scripts en una estructura de directorio
Cree los archivos necesarios de empaquetado
Cuide las referencias (imports) intra-paquete
Verifique que el código siga el PEP 8
Agregue Python annotations a sus funciones
Verifique que sus funciones tengan docstrings
Agregue pruebas unitarias y de integración que crea convenientes
Hacer ejecutable el módulo y probarlo en un venv

### Parte 2
Cree un repositorio en su cuenta de GitHub y suba el proyecto