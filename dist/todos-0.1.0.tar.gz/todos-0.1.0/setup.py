# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['todos',
 'todos.src',
 'todos.tests',
 'todos.tests.integration',
 'todos.tests.unit']

package_data = \
{'': ['*'], 'todos': ['data/*']}

setup_kwargs = {
    'name': 'todos',
    'version': '0.1.0',
    'description': 'Paquete para generar todo list',
    'long_description': '## modulo_II\n\nEn este repositorio se encuentra la resolucion alas siguientes tareas:\n\n### Parte 1\nModifique lo necesario con el fin de ver reflejado las buenas prácticas que hemos aprendido hasta el momento, a saber\n\nOrganizar el código o los scripts en una estructura de directorio\nCree los archivos necesarios de empaquetado\nCuide las referencias (imports) intra-paquete\nVerifique que el código siga el PEP 8\nAgregue Python annotations a sus funciones\nVerifique que sus funciones tengan docstrings\nAgregue pruebas unitarias y de integración que crea convenientes\nHacer ejecutable el módulo y probarlo en un venv\n\n### Parte 2\nCree un repositorio en su cuenta de GitHub y suba el proyecto',
    'author': 'RoSaavedra',
    'author_email': '55178179+RoSaavedra@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
